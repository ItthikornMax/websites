function myFunction1() 
{
    var x = document.getElementById("Cols4");
    if (x.className === "col-4") 
    {
        x.className = "col-12";
    } 
    else 
    {
        x.className = "col-4";
    }
    var x = document.getElementById("Cols8");
    if (x.className === "col-8") 
    {
        x.className = "";
    } 
    else 
    {
        x.className = "col-8";
    }
}