<?php
date_default_timezone_set('Asia/Bangkok');
$Date1 = date("d");
$Date2 = date("m");
$Date3 = date("Y");
$Date4 = date("w");
$Date5 = date("t");
if ($Date2 == 1) {
	$Month = "มกราคม";
} else if ($Date2 == 2) {
	$Month = "กุมภาพันธ์";
} else if ($Date2 == 3) {
	$month = "มีนาคม";
} else if ($Date2 == 4) {
	$Month = "เมษายน";
} else if ($Date2 == 5) {
	$Month = "พฤษภาคม";
} else if ($Date2 == 6) {
	$Month = "มิถุนายน";
} else if ($Date2 == 7) {
	$Month = "กรกฎาคม";
} else if ($Date2 == 8) {
	$Month = "สิงหาคม";
} else if ($Date2 == 9) {
	$Month = "กันยายน";
} else if ($Date2 == 10) {
	$Month = "ตุลาคม";
} else if ($Date2 == 11) {
	$Month = "พฤศจิกายน";
} else if ($Date2 == 12) {
	$Month = "ธันวาคม";
}
$Year = $Date3 + 543;
?>