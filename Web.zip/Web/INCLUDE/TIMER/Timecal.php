<?php
date_default_timezone_set('Asia/Bangkok');
function time_diff($time1, $time2) {
	$Time1 = (strtotime($time1) - strtotime($time2)) / 60;
    $Time2 = $Time1 / 60;
    if ($Time1 >= 60)
    {
        $Time1 %= 60;
    }
    else
    {
        $Time1 %= 60;
    }
    if ($Time2 >= 24)
    {
        @$Time3 = $Time2 / 24;
        $Time4 = $Time2 % 24;
    }
    if (@$Time3 > 0)
    {
        return floor($Time3)." วัน ".floor($Time4)." ชั่วโมง";
    }
    else
    {
        return floor($Time2)." ชั่วโมง ".$Time1." นาที";
    }
}
?>