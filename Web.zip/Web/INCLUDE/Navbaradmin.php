<div class="row" style="font-size: 18px; height: 100%; justify-content: center; align-items: center;">
    <div class="col-4" id="Cols4">
        <div class="dateandtime">
            <script type="text/javascript" src="INCLUDE/TIMER/Week.js"></script>
            <?php echo " " . $Date1 . " เดือน" . $Month . " พ.ศ." . $Year . " เวลา"; ?>
            <input type="text" name="showTime" size="6" class="input" disabled="disabled" style="border-top-style: none; border-right-style: none; border-bottom-style: none; border-left-style: none; font-size: 18px;">
        </div>
    </div>
    <div class="col-8" id="Cols8">
        <div class="menu">
        <div class="dropdown1">
                <a href="javascript:void(0);" style="font-size:20px;" class="icon" onClick="myFunction()">☰</a>
            </div>
            <div class="topnav" id="myTopnav">
                <div class="dropdown">          
                    <button class="dropbtn">
                        <a href="Profile.php" title="<?php echo $_SESSION['sess.Names']." ".$_SESSION['sess.Lastname']; ?>"><?php echo $_SESSION['sess.Names']." ".$_SESSION['sess.Lastname']; ?></a>
                    </button>
                </div>
                <div class="dropdown">
                    <button class="dropbtn">
                        <a href="Logout.php" title="ออกจากระบบ">ออกจากระบบ</a>
                    </button>
                </div>
                <div class="dropdown">
                    <button class="dropbtn" >
                        <a href="#" title="อัพเดทข้อมูล">อัพเดทข้อมูล</a>
                    </button>
                    <div class="dropdown-content">
                        <a href="javascript:alert('หน้านี้ยังไม่เปิดใช้งาน3')" title="แก้ไขข้อมูล">แก้ไขข้อมูล</a>
                    </div>
                </div>
                <div class="dropdown">
                    <button class="dropbtn">
                        <a href="#" title="ข้อมูลล่วนบุคคล">ข้อมูลล่วนบุคคล</a>
                    </button>
                    <div class="dropdown-content">
                        <a href="javascript:alert('หน้านี้ยังไม่เปิดใช้งาน1')" title="สถานะแบบ Realtime">สถานะแบบ Realtime</a>
                        <a href="javascript:alert('หน้านี้ยังไม่เปิดใช้งาน2')" title="ประวัติผู้ลงทะเบียน">ประวัติผู้ลงทะเบียน</a>
                    </div>
                </div>
                <div class="dropdown">
                    <button class="dropbtn">
                        <a href="javascript:alert('หน้านี้ยังไม่เปิดใช้งาน')" title="ติดต่อ">ติดต่อ</a>
                    </button>
                </div>
                <div class="dropdown">
                    <button class="dropbtn">
                        <a href="Home.php" title="หน้าหลัก">หน้าหลัก</a>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>