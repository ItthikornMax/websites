function myFunction() 
{
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") 
    {
        x.className += " responsive";
    } 
    else 
    {
        x.className = "topnav";
        
    }
    myFunction1();
    var x = document.getElementById("Cols12");
    if (x.className === "col-6") 
    {
        x.className = "col-12";
    } 
    else 
    {
        x.className = "col-6";
    }
    var x = document.getElementById("Cols0");
    if (x.className === "col-6") 
    {
        x.className = "";
    } 
    else 
    {
        x.className = "col-6";
    }
}