<?php
    session_start();
    ob_start()
?>
<html>
    <head>
        <meta charset="uft-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <?php include "INCLUDE/TIMER/Date.php"; ?>
        <link rel="stylesheet" href="CSS/Style.css">
        <link rel="stylesheet" href="CSS/Dropdown.css">
        <link rel="stylesheet" href="CSS/Button.css">
        <link rel="stylesheet" href="CSS/Responsive.css">
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
        <!-- JavaScript Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script type="text/javascript" src="INCLUDE/TIMER/Time.js"></script>
        <script type="text/javascript" src="INCLUDE/Mytopnav.js"></script>
        <script type="text/javascript" src="INCLUDE/Myfunction.js"></script>
        <title>หน้าหลักอิทธิกร</title> 
    </head>
    <body onload="StartClock24();">
        <form id="Formhome" name="clock" method="post" action="Home.php">
            <div class="coast-container">
                <div class="row" style="background-color: 9966FF; height: 15%; text-align: center;">
                    <div class="col-12" style="display: flex; justify-content: center; align-items: center;">
                        <font size="5">ยินดีต้อนรับเข้าสู่เว็บไซต์ของ Itthikorn Max Sound</font>
                    </div>
                </div>
                <div class="row" style="background-color: CC66FF; height: 55px;">
                    <div class="col-12" style="align-items: center; width: 100%; ">
                        <?php
                            if (@$_SESSION['sess.Username_Login'] == "")
                            {
                                include "INCLUDE/Navbarguest.php";
                            }
                            else
                            {
                                include "INCLUDE/Includedata.php";
                                if (@$_SESSION['Admin'] != "")
                                {
                                    include "INCLUDE/Navbaradmin.php";
                                }
                                if (@$_SESSION['Guest'] != "")
                                {
                                    include "INCLUDE/Navbaruser.php";
                                }
                            }
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12" style="width: 100%; margin-top: 5px;">
                        <?php
                            //include "INCLUDE/Headernews.php";
                        ?>
                    </div>
                </div>
            </div>
        </form>
    </body>
</html>